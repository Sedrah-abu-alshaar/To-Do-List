let lists = {
    "Work": [],
    "Personal": [],
    "List 1": []
};
let currentList = "Today"; 

function openList(listName) {
    currentList = listName;
    document.getElementById("currentListTitle").innerText = listName;
    displayTasks();
}

function addTask() {
    let taskInput = document.getElementById("newTask");
    let taskText = taskInput.value.trim();

    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    if (!lists[currentList]) {
        lists[currentList] = [];
    }

    lists[currentList].push(taskText);
    taskInput.value = "";
    displayTasks();
}

function removeTask(index) {
    lists[currentList].splice(index, 1);
    displayTasks();
}

function displayTasks() {
    let taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    if (!lists[currentList]) return;

    lists[currentList].forEach((task, index) => {
        let li = document.createElement("li");
        li.classList.add("task-item");
        li.innerHTML = `
            <span class="task-text">${task}</span>
            <button class="delete" onclick="removeTask(${index})">❌</button>
        `;
        li.querySelector(".task-text").addEventListener("click", function () {
            this.classList.toggle("completed");
        });

        taskList.appendChild(li);
    });
}

function addNewList() {
    let listName = prompt("Enter new list name:");
    if (listName && !lists[listName]) {
        lists[listName] = [];
        let listItem = document.createElement("li");
        listItem.textContent = listName;
        listItem.onclick = function () { openList(listName); };
        document.getElementById("lists").appendChild(listItem);
    }
}
